package com.example.florian.aninterface;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{
    //Button button6=new Button(this);
  //  Button button20=new Button(this);
    private int score, score2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        score = getIntent().getIntExtra("score",0);
        score2=getIntent().getIntExtra("score2",0);

        TextView textplay1= (TextView) findViewById(R.id.play1);
        textplay1.setText("Player 1:"+score);

        TextView textplay2=(TextView) findViewById(R.id.play2);
        textplay2.setText("Player 2:"+score2);

        Button  button6=(Button) findViewById(R.id.button6);
        button6.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(MainActivity.this, DiceActivity.class);
                intent.putExtra("max",6);
                startActivity(intent);
            }
        });

        Button  button20=(Button) findViewById(R.id.button20);
        button20.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this, DiceActivity.class);
                intent.putExtra("max",20);
                startActivity(intent);
            }
        });
    }
}

/*AnimatorSet set= (AnimatorSet) AnimatorInflater.loadAnimator(getApplicationContext(), R.animator.property_animator);
        set.setTarget(this);
        set.start();*/
