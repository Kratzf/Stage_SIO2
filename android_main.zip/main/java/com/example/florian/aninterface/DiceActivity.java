package com.example.florian.aninterface;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.security.SecureRandom;

/**
 * Created by florian on 31/01/2017.
 */

public class DiceActivity extends Activity{
    private int max, score=0, compteur=0, score2=0;
    private TextView textResult;
   // TextView textTitle= new TextView(this);
    //private TextView textResult=new TextView(this);
   // Button buttonRoll= new Button(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dice);

        max=getIntent().getIntExtra("max",0);

        final TextView   textTitle= (TextView) findViewById(R.id.textTitle);
        textTitle.setText(max + " sided dice");

        textResult=((TextView) findViewById(R.id.textResult));
        textResult.setText("");

        final Button  buttonRoll= (Button) findViewById(R.id.buttonRoll);
        buttonRoll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SecureRandom random= new SecureRandom();
                int result= random.nextInt(max) + 1;
                if(compteur==4) {
                    textResult.setText("Fini");
                    buttonRoll.setText("Go Player2");
                }
                else if(compteur<4){
                    score=score+result;
                    if(score>max) {
                        textResult.setTextSize(70);
                        textResult.setText("Perdu :"+score);
                    }
                    else{
                        compteur=compteur+1;
                        textResult.setText(String.valueOf(result));
                    }

                }
                else if(compteur>4 && compteur<8) {
                    textResult.setText("");
                    buttonRoll.setText("Roll the dice");
                    score2=score2+result;
                    if(score2>max) {
                        textResult.setTextSize(70);
                        textResult.setText("Perdu :"+score2);
                    }
                    else{
                        compteur=compteur+1;
                        textResult.setText(String.valueOf(result));
                    }
                }
                else textResult.setText("Fini");
            }
        });

        Button buttonre= (Button) findViewById(R.id.buttonretour);
        buttonre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(DiceActivity.this, MainActivity.class);
                intent.putExtra("score",score);
                startActivity(intent);
            }
        });
    }
}
