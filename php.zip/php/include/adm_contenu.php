<?php
//include('BDD.php');
	$message="";
	$contenu="";
	$titre="";
	
	if(isset($_POST['contenu'])){
		$connexion=new BDD('images');
			$contenu=$_POST['contenu'];
			$titre=$_POST['titre'];
			
			$requete="UPDATE text_adm set contenu='$contenu' where titre='$titre'";
			$tab=$connexion->insert($requete);
			if($tab == null){
				$message= "Probleme pour executer cette requete";
				//header("location:adm_img.php");
			}
			else {
				$message= "succes";
				echo $requete;
				//header("location:adm_img.php");
			}
	}
?>