<?php
	include('BDD.php');
	$connexion=new BDD('images');
	
	$titre="";
	$dossier_dest='img/';
	if(isset($_POST['titre'])){
		$titre=$_POST['titre'];
		if($titre=='') {
			echo "N oubliez pas le titre";
		}
		else {
			/*$sql= "INSERT INTO img_admin(titre) VALUES('$titre')";
			$resultats = $connexion->insert($sql);*/
			$sql2="INSERT INTO text_adm(titre) VALUES('$titre')";
			$resultats2 = $connexion->insert($sql2);
			
			if(!empty($_FILES)) {
				try {
					$img = $_FILES['img'];
					$ext = strtolower(substr($img['name'],-3));
					$allow_ext= array("jpg",'png','gif');
					if(in_array($ext,$allow_ext)) {
						
						 //echo "Il faut un titre !";
						if(move_uploaded_file($img['tmp_name'],$dossier_dest.$titre.'.jpg')) {
							echo "image conserve";
						}
						else {
							echo "c'est tout casse"; 
						}
					}
					else {
						$erreur="Votre fichier n'est pas une image";
					}
				}
				catch(PDOException $e) {
					die('echec : '.$e->getMessage());
				}
				
			}
		}
	}
	
?>