<?php
	include('BDD.php');
	$message="";
	$login="";
	$mdp="";
	
	if(isset($_POST['login'])){
		$connexion=new BDD('images');
			$login=$_POST['login'];
			$mdp=$_POST['mdp'];
			
			$requete="select code, login, mdp from admin where mdp='$mdp' and login='$login';";
			$tab=$connexion->select($requete);
			//on met en place une vérification quant à la saisie du mdp et du login
			if($tab == null){
				$message= "Mot de passe ou nom de compte incorrectes";
				header("location:index.php");
			}
			else {
				session_start();
				$_SESSION['code']=$tab[0]["code"]; 
				header("location:adm_img.php");
			}
	}
?>