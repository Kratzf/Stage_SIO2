<?php
include("../BDD.php");
$connexion = new BDD('images');
$id = $_POST['id'];
//charger la liste des employes avec le selectionné
// dans la liste
$requete = "select id, contenu
	from text_adm
	where id = $id";

$resultats = $connexion->select($requete);
if (is_array($resultats)) {
    $listeDT = json_encode($resultats);
    echo $listeCont;
} else {
    echo "probleme";
}
?>