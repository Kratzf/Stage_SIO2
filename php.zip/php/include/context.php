<?php
//inclusion du modèle
//include("BDD.php");
$connexion = new BDD('images');
$message = "";
$id = 0;
//On remplit la liste des employés
$requete = "select id, titre from text_adm order by titre";


$resultats = $connexion->select($requete);

if (is_array($resultats)) {
    $listeTitle = "<select id='id' name='id'>\n";
	
	if($resultats==null) {
		echo "";
	}
	else {
		$id = $resultats[0]['id'];
	}

    foreach ($resultats as $ligne) {
        $selected = "";
        if ($ligne['id'] == $id) {
            $selected = "selected";
        }
        $listeTitle = $listeTitle . "<option $selected value='" . $ligne['id'] . "'>" . $ligne['titre'] . "</option>\n";
    }
    $listeTitle = $listeTitle . "</select>";
}
//Charger la liste des employés avec le premier service
$requete = "select id, contenu from text_adm
	where id = $id";

$resultats = $connexion->select($requete);
if (is_array($resultats)) {
    $nb = count($resultats);
    if ($nb > 0) {
        $listeCont = "<form name='id' id='id' size='$nb'>\n";
        foreach ($resultats as $ligne) {
            $listeCont = $listeCont . "<textarea value='" . $ligne['id'] . "'> " . $ligne['contenu'] . "</textarea>\n";
        }
        $listeCont = $listeCont . "</form>";
    } else {
        $listeCont = "Aucune context";
    }
}
?>