$(function() {
	
	var o = {
		message : "Déposez vos fichiers ici",
		script: 'upload.php'
	}
	
	$.fn.dropfile= function(oo) {
		if(oo) $.extend(o,oo);
		//alert('blob');
		this.each(function() {
			$('<span>').addClass('instructions').append(o.message).appendTo(this);
			$(this).bind( {
				dragenter : function(e) {
					e.preventDefault();
					$(this).addClass('hover');
					console.log('dragenter');
				},
				dragover :function(e) {
					e.preventDefault();
					console.log('dragover');
				},
				dragleave :function(e) {
					e.preventDefault();
					$(this).removeClass('hover');
					console.log('dragleave');
				}
			});
				this.addEventListener('drop', function(e){
					e.preventDefault();
					var files= e.dataTransfer.files;
					upload(files,$(this),0);
				}, false);
		});
		
		function upload(files, area, index) {
			var file= files[index]; 
			//console.log(file);
			var xhr= new XMLHttpRequest();
			xhr.open('post',o.script,true);
			xhr.setRequestHeader('content-type','multipart/form-data');
			xhr.setRequestHeader('x-file-type',file.type);
			xhr.setRequestHeader('x-file-size',file.size);
			xhr.setRequestHeader('x-file-name',file.name);
			xhr.send(file);
			location.reload();
		}
	}
});