<?php
include('BDD.php');
$connexion=new BDD('images');

	$h= getallheaders();
	print_r($h);
	
	$source= file_get_contents('php://input');
	file_put_contents('img/'.$h['x-file-name'],$source);
	
	$pos_point=strpos($h['x-file-name'],'.');
	$titre=substr($h['x-file-name'],0,$pos_point);
	
	$sql2="INSERT INTO text_adm(titre) VALUES('$titre')";
	$resultats2 = $connexion->insert($sql2);
?>