<?php
session_start();
if (isset($_SESSION['code'])) {
	$message="";
	require_once("include/adm_ajout.php");
	include("include/adm_contenu.php");
	include("include/context.php");
}
else {
	header("location:index.php");
}	
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href='style.css'/>
	<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script type="text/javascript" src="dropfile.js"></script>
	<script type="text/javascript">
		$(function() {
			$('.dropfile').dropfile();
		});
	</script>
</head>

<body>
<form method="post" action="adm_img.php" enctype="multipart/form-data">
Titre: <input type="text" name="titre"/>
<input type="file" name="img"/>
<input type="submit" name="Envoyer"/>
<a href="deconnexion.php" style="float: right;">Deconnexion</a>
<a class="cont" href="#">Ajoutez un contenu</a>
<a class="cont2" href="#" style="padding-left:20px;">Voir les contenus</a>
</form>
<?php
if(isset($erreur)){
	echo $erreur;
}
?>
<aside><marquee class="mark" scrollamount="10" onmouseout="this.start()" onmouseover="this.stop()" style="background-color:#B0C4DE;">
	<?php
	$dos="img";
	$dir= opendir($dos);
	while($file= readdir($dir)) {
		$allow_ext= array("jpg",'png','gif');
		$ext = strtolower(substr($file,-3));
		if(in_array($ext,$allow_ext)) {
			?>
			<img width="200px" height="200px" src="img/<?php echo $file; ?>" style="border:1px solid red; margin-left:10px;" /></a>
			<?php
		}
	}
?>
			</marquee></aside>
			<form class="cache" method="post">
				Titre: <select name="titre">
			<?php
				include('BDD');
				$connexion=new BDD('images');
						$sql="SELECT * FROM text_adm;";
						$tab=$connexion->select($sql);
						$max=count($tab);
						for($i=0;$i<$max;$i=$i+1){
						$ligne=$tab[$i];
						echo "<option value='",$ligne['id'],"'>",$ligne['titre'],"</option>";
						}
			
			?>
			</select>
				<textarea name="contenu"> </textarea>
				<input type="submit" name="Envoyer"/>
			</form>
			
			<form name="adm_img" method="post" class="cache2">
                    <span class='label bold'>Choisir le titre</span><?php echo $listeTitle; ?><br/><br/>
                    <span style='vertical-align: top' class='label bold'>Affichage du contenu</span><span id="select-DT"><?php echo $listeCont; ?></span>
                </form>
		<span><?php echo $message; ?></span>
		</br></br>
		<div class="dropfile">
			
		</div>
<script src="jquery.js"></script>
<script>
$(document).ready(function(){ 
	$('.cache').hide();
	
	$('.cont').click(function()
                {
                   $('.cache').show('slow');
                });
				
	$('.cache2').hide();
	
	$('.cont2').click(function()
                {
                   $('.cache2').show('slow');
                });
				
	var listeCont = $('#id');
    var listeTitle = $('#id');
    listeTitle.change(function () {
    var id = listeTitle.val();
    $.ajax({
        url: 'include/ajax_json.php',
        type: 'POST',
         data: 'id=' + id,
        dataType: 'json',
        success: function (donneesJSON, statut) {

        var nb = donneesJSON.length;
        var resultat = " <form name='id' id='id' size='" + nb + "'>";
        for (var i = 0; i < nb; i++)
            {
            /* Concaténation du résultat */
            resultat += "<textarea value=" + donneesJSON[i].id + ">"
            + donneesJSON[i].contenu + "</textarea>";

            }
        resultat += "</form>"
        listeCont.html(resultat)
        },
        error: function () {
            listeCont.html('<select><option>big pb</option></select>');
            },
        });
    });
});
</script>
</body>
</html>