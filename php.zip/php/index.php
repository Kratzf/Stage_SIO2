<?php
	require("include/login.php");
?>
<!DOCTYPE html>
<html>
<header>
</header>

	<head>
		<meta charset='utf-8' />
		<!--<link rel='stylesheet' href='CSS/style.css' />-->
		
		<title>Image</title>
	</head>
		
	<body>
	<h1>Gestion des images</h1>
	
	
	<section>
    <form name="identification" method="POST" action="index.php" >
       
           Login <input name="login" type="text" value="<?php echo $login;?>"  />
      
            Mot de passe <input name="mdp" type="password" value="<?php echo $mdp;?>"/></br>
       
            <input type="submit"/>
			 </form>
      <br>
	  <?php echo $message ?>
   
</section>
	
</body>
</html>