<?php
	if(!empty($_FILES)) {
		
		$img = $_FILES['img'];
		$ext = strtolower(substr($img['name'],-3));
		$allow_ext= array("jpg",'png','gif');
		if(in_array($ext,$allow_ext)) {
			move_uploaded_file($img['tmp_name'],"img/".$img['name']);
		}
		else {
			$erreur="Votre fichier n'est pas une image";
		}
	}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr">
<head>
<link rel="stylesheet" type="text/css" href="theme/style.css" />
</head>

<body>
<?php
if(isset($erreur)){
	echo $erreur;
}
?>
<form method="post" action="index.php" enctype="multipart/form-data">
<input type="file" name="img"/>
<input type="submit" name="Envoyer"/>
</form>

<?php
	$dos="img";
	$dir= opendir($dos);
	while($file= readdir($dir)) {
		$allow_ext= array("jpg",'png','gif');
		$ext = strtolower(substr($file,-3));
		if(in_array($ext,$allow_ext)) {
			?>
			<a href="img/<?php echo $file; ?>">
			<img src="img/<?php echo $file; ?>"/>
			<h3><?php echo $file; ?></h3>
			</a>
			<?php
		}
	}
?>
</body>

</html>